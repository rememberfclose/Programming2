#include <stdio.h>
#include <math.h>
typedef struct {
	float Re;
	float Im;
}kb;
void ulaz(kb* z){
	printf("Re: ");
	scanf("%f", &(*z).Re);
	printf("Im: ");
	scanf("%f", &(*z).Im);
}
void ispisi(kb z){
	if(z.Re==0 && z.Im==0)
		{printf("0\n");
				return;}

	if(z.Re!=0)
	printf("%.2f ", z.Re);
	if(z.Im!=0)
	{
		if(z.Im<0){
			printf("- %.2fi", fabs(z.Im));
		}
		else 
			printf("+ %.2fi", z.Im);
	}
	printf("\n");
}
float rdb(kb z){
	return z.Re;
}
float idb(kb z){
	return z.Im;
}
float moduo(kb z){

return sqrt(z.Im*z.Im+z.Re*z.Re);

}

kb konj(kb z)
{
	z.Im=-z.Im;
	return z;
}
kb zbir(kb z1, kb z2){
	kb z3;
	z3.Im=z1.Im+z2.Im;
	z3.Re=z1.Re+z2.Re;
	return z3;
}
kb razlika(kb z1, kb z2){
	kb z3;
	z3.Im=z1.Im-z2.Im;
	z3.Re=z1.Re-z2.Re;
	return z3;
}
kb proizvod(kb z1, kb z2){
	kb z3;
	z3.Re=z1.Re*z2.Re-z1.Im*z2.Im;
	z3.Im=z1.Re*z2.Im+z1.Im*z2.Re;
	return z3;
}

float arg(kb z){
	return atan2(z.Im, z.Re);
}

int main()
{
	kb a, b;

	
	
	return 0;
}