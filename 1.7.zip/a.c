#include <stdio.h>
#include "b.h"



int main()
{	int x;
	scanf("%x",&x);
	stampaj_bint((x));
	stampaj_bint(najmanji(x));
	
	

	



	return 0;
}