#include <stdio.h>
void stampaj_bort(unsigned short x)
{
	unsigned vel=sizeof(unsigned short)*8;
	unsigned mask=1<<(vel-1);

	for (; mask; mask>>=1)
	{
		if(x&mask)
			printf("1");
		else printf("0");
	}
	printf("\n");
}
unsigned prebroj_bitove_1(int x){
unsigned vel=sizeof(int)*8;
unsigned mask=1;
unsigned zbir=0;
for(;mask;mask<<=1){
	if(x&mask)
		zbir++;
}
return zbir;
}

unsigned najveci(unsigned x){
	int preb=prebroj_bitove_1(x);
	unsigned y=0;
	return (~y<<(sizeof(unsigned)-4-preb));
}


void stampaj_bint(unsigned x)
{
	unsigned vel=sizeof(unsigned)*8;
	unsigned mask=1<<(vel-1);

	for (; mask; mask>>=1)
	{
		if(x&mask)
			printf("1");
		else printf("0");
	}
	printf("\n");
}

void stampaj_bhar(unsigned char x)
{
	unsigned vel=sizeof(unsigned char)*8;
	unsigned mask=1<<(vel-1);

	for (; mask; mask>>=1)
	{
		if(x&mask)
			printf("1");
		else printf("0");
	}
	printf("\n");
}
unsigned ogledalo(unsigned x){

	unsigned temp=x;
	unsigned vel=sizeof(unsigned)*8;
	unsigned maskb=1, maskf=1<<(vel-1);
	for(int i=0;i<vel/2;i++){
		 if((x&maskb)==0){
		 
		 	temp=temp&(~maskf);
		 	}
		 else if((x&maskb)!=0){
		 	temp=temp|maskf;
		 	}
		if((x&maskf)==0){
		 	temp=temp&(~maskb);
		 	}
		 else if((x&maskf)!=0){
			temp=temp|maskb;
			}
	maskb<<=1;
	maskf>>=1;

	}
	return temp;
	}
unsigned najmanji(unsigned x){
	return ogledalo(najveci(x));
}