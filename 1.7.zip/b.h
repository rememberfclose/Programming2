#ifndef __STAMPANJE_H__
#define __STAMPANJE_H__ 1
 
void stampaj_bort(unsigned short x);
void stampaj_bint(unsigned x);
void stampaj_bhar(unsigned char x);
unsigned prebroj_bitove_1(int x);
unsigned ogledalo(unsigned x);
unsigned najveci(unsigned x);
unsigned najmanji(unsigned x);
#endif