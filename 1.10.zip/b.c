#include <stdio.h>
void stampaj_bort(unsigned short x)
{
	unsigned vel=sizeof(unsigned short)*8;
	unsigned mask=1<<(vel-1);

	for (; mask; mask>>=1)
	{
		if(x&mask)
			printf("1");
		else printf("0");
	}
	printf("\n");
}
unsigned ogledalo(unsigned x){

	unsigned temp=x;
	unsigned vel=sizeof(unsigned)*8;
	unsigned maskb=1, maskf=1<<(vel-1);
	for(int i=0;i<vel/2;i++){
		 if((x&maskb)==0){
		 
		 	temp=temp&(~maskf);
		 	}
		 else if((x&maskb)!=0){
		 	temp=temp|maskf;
		 	}
		if((x&maskf)==0){
		 	temp=temp&(~maskb);
		 	}
		 else if((x&maskf)!=0){
			temp=temp|maskb;
			}
	maskb<<=1;
	maskf>>=1;

	}
	return temp;
	}

unsigned vrati_bitove(unsigned x, unsigned n, unsigned p){

	unsigned vel=sizeof(unsigned)*8;
	return ((((x)>>(p-n+1))<<(p-n+1))<<(vel-p-1))>>(vel-p-1);
}

unsigned postavi_1(unsigned x, unsigned n, unsigned p)
{
	unsigned mask=((~((~0<<(p+1))>>(p-n+1))<<(p-n+1)));
	return x|mask;
}
unsigned postavi_0(unsigned x, unsigned n, unsigned p){
	unsigned mask=(~(~((~0<<(p+1))>>(p-n+1))<<(p-n+1)));
	return x&mask;
}
unsigned invertuj(unsigned x, unsigned n, unsigned p){

	return (postavi_0(x,n,p)|vrati_bitove(~x, n, p));
}
unsigned postavi_1_n_bitove(unsigned x, unsigned n, unsigned p, unsigned y){
unsigned vel=sizeof(unsigned)*8;
	return(postavi_0(x,n,p)|((y<<(vel-n))>>(vel-n))<<(p-n+1));

}
void stampaj_bint(unsigned x)
{
	unsigned vel=sizeof(unsigned)*8;
	unsigned mask=1<<(vel-1);

	for (; mask; mask>>=1)
	{
		if(x&mask)
			printf("1");
		else printf("0");
	}
	printf("\n");
}

void stampaj_bhar(unsigned char x)
{
	unsigned vel=sizeof(unsigned char)*8;
	unsigned mask=1<<(vel-1);

	for (; mask; mask>>=1)
	{
		if(x&mask)
			printf("1");
		else printf("0");
	}
	printf("\n");
}
