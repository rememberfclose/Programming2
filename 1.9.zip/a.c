#include <stdio.h>
#include "b.h"

int main()
{	unsigned p=3;
	unsigned x=-15;
	 scanf("%x",&x);
	 scanf("%u", &p);
	
	stampaj_bint(x);
	stampaj_bint(rotiraj_udesno_oznaceni(x,p));



	return 0;
}