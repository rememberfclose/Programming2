#ifndef __STAMPANJE_H__
#define __STAMPANJE_H__ 1
 
void stampaj_bort(unsigned short x);
void stampaj_bint(unsigned x);
void stampaj_bhar(unsigned char x);
unsigned postavi_0(unsigned x, unsigned n, unsigned p);
unsigned postavi_1(unsigned x, unsigned n, unsigned p);
unsigned vrati_bitove(unsigned x, unsigned n, unsigned p);
unsigned invertuj(unsigned x, unsigned n, unsigned p);
unsigned postavi_1_n_bitove(unsigned x, unsigned n, unsigned p, unsigned y);
unsigned ogledalo(unsigned x);
unsigned rotiraj_ulevo(unsigned x, unsigned p);
unsigned rotiraj_udesno(unsigned x, unsigned p);
int rotiraj_udesno_oznaceni(int x, unsigned p);
#endif