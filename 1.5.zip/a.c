#include <stdio.h>
#include "b.h"

int main()
{	int x;
	scanf("%x",&x);

	stampaj_bint(x);

	return 0;
}