#ifndef ___raz___h
#define ___raz___h


struct raz
{
	long long p;
	long long q;
};

long long ocd(int n1, int n2);
struct raz proizvod(struct raz a, struct raz b);
struct raz zbir(struct raz a, struct raz b);
struct raz ucitaj();
void stampaj(struct raz* a);
long long brojilac(struct raz* p);
long long imenilac(struct raz* p);
double realna(struct raz* p);
double recip(struct raz* p);
struct raz skrati(struct raz* c);
struct raz razlika(struct raz a, struct raz b);
struct raz deli(struct raz a, struct raz b);
#endif