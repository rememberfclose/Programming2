#include <stdio.h>
#include "b.h"


int main()
{	
struct raz x, y,z ;

x=ucitaj();
y=ucitaj();
z=deli(x,y);
stampaj(&z);






	return 0;
}