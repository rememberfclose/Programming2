#include <stdio.h>
#include "b.h"


long long ocd(int n1, int n2)
{
 	long long i, ocd=1;
    if (n1<0)
    {
    	n1=-n1;
    }
    if (n2<0)
    {
    	n2=-n2;
    }
    for (i = 1; i<=n1 && i<=n2; ++i)
    {
    	if (n1%i==0 && n2%i==0)
    		ocd=i;
    }

    return ocd;
}

struct raz zbir(struct raz a, struct raz b)
{
struct raz c;
int n;
c.p=a.p*b.q+b.p*a.q;
c.q=a.q*b.q;
n=ocd(c.p, c.q);
c.p=c.p/n;
c.q=c.q/n;
return c;
}

struct raz proizvod(struct raz a, struct raz b)
{
struct raz c;
int n;
c.p=a.p*b.p;
c.q=a.q*b.q;
n=ocd(c.p, c.q);
c.p=c.p/n;
c.q=c.q/n;
return c;
}

struct raz ucitaj(){
	struct raz resenje;
	scanf("%lli %lli", &resenje.p, &resenje.q);
	return resenje;
}
void stampaj(struct raz* a){
printf("%lli/%lli\n", (*a).p, (*a).q);
}
long long brojilac(struct raz* p){
	return (*p).p;
}
long long imenilac(struct raz* p){
	return (*p).q;
}
double realna(struct raz* p){
	return (double)(*p).p/(*p).q;

}
double recip(struct raz* p){
	return (double)(*p).q/(*p).p;

}
struct raz skrati(struct raz* c){
	struct raz resenje;
	int n=ocd((*c).p, (*c).q);
	resenje.p=(*c).p/n;
	resenje.q=(*c).q/n;
	return resenje;
}
struct raz razlika(struct raz a, struct raz b)
{
struct raz c;
int n;
c.p=a.p*b.q-b.p*a.q;
c.q=a.q*b.q;
n=ocd(c.p, c.q);
c.p=c.p/n;
c.q=c.q/n;
return c;
}
struct raz deli(struct raz a, struct raz b)
{
struct raz c;
int n;
c.p=a.p*b.q;
c.q=a.q*b.p;
n=ocd(c.p, c.q);
c.p=c.p/n;
c.q=c.q/n;
return c;
}