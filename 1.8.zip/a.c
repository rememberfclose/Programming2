#include <stdio.h>
#include "b.h"

int main()
{	unsigned x,y;
	scanf("%x%x",&x, &y);
	int p,n;

	scanf("%d%d", &p, &n);

	stampaj_bint(postavi_1_n_bitove(x,n,p,y));


	return 0;
}