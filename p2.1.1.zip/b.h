#ifndef _POLH_
#define _POLH_


typedef struct {
float a[20];
int polen;
}Polinom;




void ispisi(Polinom* p);
Polinom ucitaj();
double izracunaj(const Polinom* p, double x);
Polinom saberi(Polinom* p, Polinom* q);
Polinom pomnozi(Polinom* p, Polinom* q);
Polinom izvod(Polinom* p);
Polinom izvod_n(const Polinom* p, int n);
#endif