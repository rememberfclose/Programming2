#include <stdio.h>
#include <string.h>
#include <math.h>
#include "b.h"

int main()
{
Polinom a;
Polinom b;
Polinom zbir;
b=ucitaj();
zbir=izvod_n(&b,1);
ispisi(&zbir);

	return 0;
}