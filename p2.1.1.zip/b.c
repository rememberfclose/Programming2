#include <stdio.h>
#include <string.h>
#include <math.h>
#include "b.h"

void ispisi(Polinom* p){

	for (int i = (*p).polen; i >= 0; --i)
{	if((*p).a[i]==0)
	continue;
	
	if (i!=(*p).polen && (*p).a[i]>0)
	{
		printf("+");
	}
	if ((*p).a[i]==1)
	{
		printf("x^(%d)",i);
		continue;
	}
	printf("%.2fx^(%d)",(*p).a[i],i);

}





}
Polinom ucitaj(){
	Polinom prvi;
int stepen;
scanf("%d", &stepen);
prvi.polen=stepen;
for (int i = stepen; i >= 0; --i)
{
	scanf("%f",&prvi.a[i]);
}
return prvi;
}

double izracunaj(const Polinom* p, double x){
	double resenje=0.0f;
	for (int i = 0; i <=(*p).polen; ++i)
	{
		resenje+=(*p).a[i]*pow(x,i);
	}
return resenje;
}

Polinom saberi(Polinom* p, Polinom* q){
	Polinom resenje;
	int kraci;
	int flag=0;
	if((*p).polen<(*q).polen)
		{
			resenje.polen=(*q).polen;
			kraci=(*p).polen;
		}
	else
		{
			resenje.polen=(*p).polen;
			kraci=(*q).polen;
		}
	for (int i = 0; i <=kraci; ++i)
	{
		resenje.a[i]=(*q).a[i]+(*p).a[i];
	}
	if((*p).polen<(*q).polen)
	for (int i = kraci+1; i <= resenje.polen; ++i)
	{
		resenje.a[i]=(*q).a[i];
	}
	else
		for (int i = kraci+1; i <= resenje.polen; ++i)
	{
		resenje.a[i]=(*p).a[i];
	}
return resenje;
}
Polinom pomnozi(Polinom* p, Polinom* q){
	Polinom resenje;
	resenje.polen=(*p).polen+(*p).polen;
	for (int i = 0; i <= resenje.polen; ++i)
	{
		resenje.a[i]=0;
	}

	for (int i = 0; i <= (*p).polen; ++i)
	{
		for (int j = 0; j <= (*q).polen; ++j)
		{
			resenje.a[i+j]+=(*p).a[i]*(*q).a[j];
		}
	}

return resenje;

}

Polinom izvod(Polinom* p){
	Polinom resenje;
	resenje.polen=(*p).polen-1;
	for (int i = 0; i <= resenje.polen; ++i)
	{
		resenje.a[i]=(*p).a[i+1]*(i+1);
	}


return resenje;
}

Polinom izvod_n(const Polinom* p, int n){
	Polinom resenje;
	resenje=(*p);
	for (int i = 0; i < n; ++i)
	{
		resenje=izvod(&resenje);
	}

return resenje;
}
